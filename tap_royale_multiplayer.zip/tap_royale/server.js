const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

const MATCH_SECONDS = 60;
const ROUND_MS = 1000;
const players = new Map();
let match = { active: false, endsAt: 0, round: 0, target: "⚡", winnerThisRound: false };
let matchTimer = null;
let roundTimer = null;
let lastWinners = [];

const targets = ["⚡", "💎", "🔥", "⭐", "🍀", "🚀"];
const cleanName = (s) => String(s || "Player").trim().replace(/[<>]/g, "").slice(0, 16) || "Player";

function publicPlayers() {
  return [...players.values()].map(p => ({
    id: p.id, name: p.name, score: p.score, wins: p.wins
  })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}
function emitState() {
  io.emit("state", {
    players: publicPlayers(),
    active: match.active,
    secondsLeft: match.active ? Math.max(0, Math.ceil((match.endsAt - Date.now()) / 1000)) : 0,
    round: match.round,
    target: match.target,
    winnerThisRound: match.winnerThisRound,
    podium: lastWinners
  });
}
function newRound() {
  if (!match.active) return;
  match.round++;
  match.target = targets[Math.floor(Math.random() * targets.length)];
  match.winnerThisRound = false;
  emitState();
}
function finishMatch() {
  if (!match.active) return;
  match.active = false;
  clearInterval(matchTimer);
  clearInterval(roundTimer);
  const ranked = publicPlayers();
  lastWinners = ranked.slice(0, 3).map((p, i) => ({ ...p, place: i + 1 }));
  lastWinners.forEach((p, i) => {
    const actual = players.get(p.id);
    if (actual && i === 0) actual.wins++;
  });
  io.emit("match-finished", { podium: lastWinners, players: publicPlayers() });
  emitState();
}
function startMatch() {
  if (match.active || players.size === 0) return;
  for (const p of players.values()) p.score = 0;
  match.active = true;
  match.endsAt = Date.now() + MATCH_SECONDS * 1000;
  lastWinners = [];
  newRound();
  matchTimer = setInterval(() => {
    if (Date.now() >= match.endsAt) finishMatch();
    else emitState();
  }, 250);
  roundTimer = setInterval(newRound, ROUND_MS);
  emitState();
}

io.on("connection", socket => {
  socket.on("join", rawName => {
    const name = cleanName(rawName);
    players.set(socket.id, { id: socket.id, name, score: 0, wins: 0 });
    socket.emit("joined", { id: socket.id, name });
    if (!match.active && players.size >= 1) {
      // Start a short countdown so several devices can join the same lobby.
      if (!startMatch.pending) {
        startMatch.pending = true;
        io.emit("notice", "Arena dibuka! Pertandingan dimulai dalam 5 detik.");
        setTimeout(() => {
          startMatch.pending = false;
          if (!match.active && players.size) startMatch();
        }, 5000);
      }
    }
    emitState();
  });

  socket.on("tap-target", data => {
    const p = players.get(socket.id);
    if (!p || !match.active || match.winnerThisRound) return;
    if (!data || data.round !== match.round) return;
    match.winnerThisRound = true;
    p.score++;
    io.emit("round-winner", { id: socket.id, name: p.name, score: p.score });
    emitState();
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
    emitState();
    if (players.size === 0 && match.active) finishMatch();
  });
});

server.listen(PORT, () => console.log(`Tap Royale berjalan di port ${PORT}`));